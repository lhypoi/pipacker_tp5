<?php
namespace app\index\controller;

class Index
{
    public function index()
    {
        return 'hello wrold';
    }

    public function sayHello()
    {
    	return 'love you~';
    }
}
