<?php
namespace app\index\controller;

class Home
{
    public function index()
    {
        return 'hello wrold in home';
    }
}
