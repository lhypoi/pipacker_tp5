<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"C:\wamp64\www\thinkphp\public/../application/admin\view\login\index.html";i:1501745491;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="__PUBLIC_ADMIN__/Bootstrap3.3.7/css/bootstrap.min.css">
	<script src="__PUBLIC_ADMIN__/Bootstrap3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	登陆界面
	<a href="" class="btn btn-info">登陆</a>
</body>
</html>